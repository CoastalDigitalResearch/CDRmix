#!/bin/bash
python3 src/train.py
