#!/bin/bash
python3 src/eval.py
