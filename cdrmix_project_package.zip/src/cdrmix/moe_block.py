# MoE block placeholder
class MoERWKVBlock:
    pass
