# RWKV block placeholder
class RWKVBlock:
    pass
