# Top-level model class placeholder
class RWKVMoEModel:
    pass
