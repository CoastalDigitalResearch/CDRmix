# Router placeholder
class MoERouter:
    pass
