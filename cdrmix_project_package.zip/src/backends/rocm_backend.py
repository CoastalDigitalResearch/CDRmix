# ROCm backend placeholder
def forward():
    pass
