# Tenstorrent backend placeholder
def forward():
    pass
