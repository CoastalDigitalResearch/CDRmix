# Torch backend placeholder
def forward():
    pass
