# Entry point for training

if __name__ == '__main__':
    print('Train loop placeholder')
